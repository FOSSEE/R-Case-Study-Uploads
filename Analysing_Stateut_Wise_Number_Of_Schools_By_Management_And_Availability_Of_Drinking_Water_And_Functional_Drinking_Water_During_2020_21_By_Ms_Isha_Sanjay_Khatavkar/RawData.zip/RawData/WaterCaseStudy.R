#setwd("D:/Btech/DYPATU C/R/FOSSE")
#getwd()
# Load required libraries
library(readr)
library(dplyr)
library(ggplot2)

# Data Collection
water_data <- read_csv("Water20-21.csv")

# Data Exploration
# View the structure of the dataset
str(water_data)

# Summary statistics
summary(water_data)

# Explore first few rows of the dataset
head(water_data)

# Explore last few rows of the dataset
tail(water_data)

# Data Analysis
# Calculate measures of central tendency and dispersion for relevant variables
# For example, let's calculate mean, median, and standard deviation of % of Schools with Drinking Water Facility
mean_drinking_water <- mean(water_data$`% of Schools with Drinking Water Facility - All Management`, na.rm = TRUE)
median_drinking_water <- median(water_data$`% of Schools with Drinking Water Facility - All Management`, na.rm = TRUE)
sd_drinking_water <- sd(water_data$`% of Schools with Drinking Water Facility - All Management`, na.rm = TRUE)

# Print the calculated statistics
cat("Mean % of Schools with Drinking Water Facility:", mean_drinking_water, "\n")
cat("Median % of Schools with Drinking Water Facility:", median_drinking_water, "\n")
cat("Standard Deviation of % of Schools with Drinking Water Facility:", sd_drinking_water, "\n")

# Calculate measures of dispersion for relevant variables

# Range
range_drinking_water <- range(water_data$`% of Schools with Drinking Water Facility - All Management`)
cat("Range of % of Schools with Drinking Water Facility:", range_drinking_water, "\n")

# Variance
var_drinking_water <- var(water_data$`% of Schools with Drinking Water Facility - All Management`, na.rm = TRUE)
cat("Variance of % of Schools with Drinking Water Facility:", var_drinking_water, "\n")

# Standard Deviation
sd_drinking_water <- sd(water_data$`% of Schools with Drinking Water Facility - All Management`, na.rm = TRUE)
cat("Standard Deviation of % of Schools with Drinking Water Facility:", sd_drinking_water, "\n")

# Hypothesis Testing
# Example 1: One-sample t-test
# Null hypothesis: The mean percentage of schools with drinking water facility is equal to 50%
# Alternative hypothesis: The mean percentage of schools with drinking water facility is not equal to 50%
t_test_result <- t.test(water_data$`% of Schools with Drinking Water Facility - All Management`, mu = 50)

# Print the results
print(t_test_result)

# Hypothesis Testing
# Example 2: Chi-square test for independence
# Null hypothesis: There is no association between school management type and the availability of drinking water facilities
# Alternative hypothesis: There is an association between school management type and the availability of drinking water facilities
chi_square_result <- chisq.test(water_data$`Total Schools - All Management`, water_data$`Schools with Drinking Water Facility - All Management`)

# Print the results
print(chi_square_result)

# For example:
# Compute correlations between variables
correlation_matrix <- cor(water_data[, -1]) # Exclude the first column (India/State/UT) for correlation computation
print(correlation_matrix)

# Create additional visualizations
# For example:
# Scatter plot to visualize the relationship between two variables
ggplot(data = water_data, aes(x = `Total Schools - All Management`, y = `Schools with Drinking Water Facility - All Management`)) +
  geom_point() +
  labs(x = "Total Schools", y = "Schools with Drinking Water Facility") +
  ggtitle("Relationship between Total Schools and Schools with Drinking Water Facility")

# For example, let's say you want to find the top 10 states/UTs with the highest % of Schools with Functional Drinking Water Facility
top_10_states <- water_data %>%
  arrange(desc(`% of Schools with Functional Drinking Water Facility - All Management`)) %>%
  slice_head(n = 10)

# Print the top 10 states/UTs
print(top_10_states)

# You can also create visualizations for the top 10 states/UTs
ggplot(data = top_10_states, aes(x = reorder(`India/ State/ UT`, `% of Schools with Functional Drinking Water Facility - All Management`), y = `% of Schools with Functional Drinking Water Facility - All Management`)) +
  geom_bar(stat = "identity", fill = "skyblue") +
  labs(x = "State/UT", y = "% of Schools with Functional Drinking Water Facility") +
  ggtitle("Top 10 States/UTs with the Highest % of Schools with Functional Drinking Water Facility") +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))


# Additional exploratory and analytical code can be added here
# Add your code here for further analysis or visualization


# Example: Boxplot of % of Schools with Drinking Water Facility - All Management by School Management Type
ggplot(data = water_data, aes(x = `Total Schools - All Management`, y = `% of Schools with Drinking Water Facility - All Management`)) +
  geom_boxplot() +
  labs(x = "Total Schools", y = "% of Schools with Drinking Water Facility") +
  ggtitle("Boxplot of % of Schools with Drinking Water Facility by School Management Type")


# Example: Scatter plot to visualize the relationship between % of Schools with Drinking Water Facility and % of Schools with Functional Drinking Water Facility
ggplot(data = water_data, aes(x = `% of Schools with Drinking Water Facility - All Management`, y = `% of Schools with Functional Drinking Water Facility - All Management`)) +
  geom_point() +
  labs(x = "% of Schools with Drinking Water Facility", y = "% of Schools with Functional Drinking Water Facility") +
  ggtitle("Relationship between % of Schools with Drinking Water Facility and % of Schools with Functional Drinking Water Facility")

# State-wise distribution of schools based on management type and drinking water facilities availability
state_distribution <- water_data %>%
  group_by(`India/ State/ UT`, `Total Schools - All Management`) %>%
  summarise(total_schools = n(), 
            total_schools_with_drinking_water = sum(`Schools with Drinking Water Facility - All Management`), 
            total_schools_with_functional_drinking_water = sum(`Schools with Functional Drinking Water Facility - All Management`))

# Inferential Statistics
# Logistic Regression Model (Example)
# Here you can perform logistic regression to predict the likelihood of schools having functional drinking water facilities based on certain predictors like management type, location, etc.

# Predictive Modeling (Example)
# Here you can use predictive modeling techniques like decision trees, random forests, etc., to predict the availability of functional drinking water facilities in schools based on various predictors.

# Visualization
# Example: Plotting % of Schools with Drinking Water Facility - All Management by State/UT
ggplot(data = water_data, aes(x = `India/ State/ UT`, y = `% of Schools with Drinking Water Facility - All Management`)) +
  geom_bar(stat = "identity") +
  labs(x = "State/UT", y = "% of Schools with Drinking Water Facility") +
  ggtitle("% of Schools with Drinking Water Facility by State/UT") +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
