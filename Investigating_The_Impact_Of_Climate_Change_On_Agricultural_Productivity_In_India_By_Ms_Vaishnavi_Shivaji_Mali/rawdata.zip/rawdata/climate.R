R.version
setwd("D:/Btech/DYPATU C/R/FOSSE")
# Check current working directory
getwd()
# Data Collection
# Load required libraries
# Install if not already installed: install.packages("readr")
library(readr)

# Load climate data from the CSV file
climate_data <- read_csv("climate_data.csv")

# Data Exploration
# Load required libraries
# Install if not already installed: install.packages("dplyr")
library(dplyr)
# Install if not already installed: install.packages("ggplot2")
library(ggplot2)

# Summary statistics
summary(climate_data)

# Explore first few rows of the dataset
head(climate_data)

# Explore trends and patterns using visualization
# Example: Line plot to visualize trends in agricultural productivity over time
ggplot(data = climate_data, aes(x = Crop_Year, y = Production)) +
  geom_line() +
  labs(x = "Crop Year", y = "Production") +
  ggtitle("Trends in Agricultural Production Over Time")

# Data Analysis
# Load required libraries
# Install if not already installed: install.packages("forecast")
library(forecast)

# Spline regression
# Example: Fit spline regression model
# Check for missing or infinite values in Crop_Year and Production columns
missing_values_crop_year <- any(is.na(climate_data$Crop_Year))
missing_values_production <- any(is.na(climate_data$Production))

infinite_values_crop_year <- any(!is.finite(climate_data$Crop_Year))
infinite_values_production <- any(!is.finite(climate_data$Production))

# Print the results
cat("Missing values in Crop_Year column:", missing_values_crop_year, "\n")
cat("Missing values in Production column:", missing_values_production, "\n")

cat("Infinite values in Crop_Year column:", infinite_values_crop_year, "\n")
cat("Infinite values in Production column:", infinite_values_production, "\n")
# Remove rows with missing values in Crop_Year or Production columns
cleaned_data <- na.omit(climate_data[c("Crop_Year", "Production")])

# Fit spline regression model with cleaned data
spline_model <- smooth.spline(cleaned_data$Crop_Year, cleaned_data$Production)


# Visualize the spline regression
plot(spline_model, main = "Spline Regression of Crop Year and Production")


# Auto-regressive model
# Example: Fit auto-regressive model
ar_model <- Arima(climate_data$Production, order = c(1, 0, 0))

# GARCH model
# Example: Fit GARCH model
# Install if not already installed: install.packages("rugarch")
# Step 3: Time Series Analysis
# Assuming 'Production' is the variable of interest for GARCH analysis
production_ts <- ts(climate_data$Production, start = c(min(climate_data$Crop_Year)), frequency = 1)

# Assuming 'Area' is another variable of interest for GARCH analysis
area_ts <- ts(climate_data$Area, start = c(min(climate_data$Crop_Year)), frequency = 1)

# Step 4: Modeling Techniques - GARCH
# Specify GARCH model for 'Area' variable
garch_spec_area <- ugarchspec(variance.model = list(model = "sGARCH", garchOrder = c(1,1)),
                              mean.model = list(armaOrder = c(0,0)))
# Fit GARCH model for 'Area' variable
garch_model_area <- ugarchfit(data = area_ts, spec = garch_spec_area)

# Print GARCH model summary
print(garch_model_area)

# Summary of GARCH model
summary(garch_fit)

#time series analysis
# Assuming 'Production' is the variable of interest for time series analysis
# Convert 'Crop_Year' to a date format if it's not already in one
climate_data$Crop_Year <- as.Date(paste0(climate_data$Crop_Year, "-01-01"))

# Aggregate data to yearly level for simplicity
production_yearly <- aggregate(Production ~ Crop_Year, data = climate_data, FUN = sum)

# Create a time series object
production_ts <- ts(production_yearly$Production, start = c(min(climate_data$Crop_Year)), frequency = 1)

# Step 2: Exploratory Data Analysis (EDA)
# Plot the time series data
autoplot(production_ts, main = "Time Series of Agricultural Production")

# Forecast future agricultural production using a forecasting method (e.g., ARIMA)
production_forecast <- forecast(auto.arima(production_ts), h = 12) # forecasting next 12 time periods

# Plot forecasted values
autoplot(production_forecast, main = "Forecast of Agricultural Production")


# Step 8: Implications and Recommendations
# Based on findings, provide insights into implications for agricultural productivity
# You may analyze the forecasted values and trends to provide insights and recommendations.
# For example, let's calculate the percentage change in production from the last observed value to the forecasted value.
last_observed_value <- production_ts[length(production_ts)]
forecasted_value <- forecast_values[length(forecast_values)]
percentage_change <- ((forecasted_value - last_observed_value) / last_observed_value) * 100

cat("Percentage Change in Production from Last Observed Value to Forecasted Value:", percentage_change, "%\n")


