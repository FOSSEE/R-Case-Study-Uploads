# Load necessary libraries
library(readr)
library(dplyr)
library(ggplot2)
library(corrplot)
library(factoextra)
library(stats)

# Load the dataset
data <- read_csv("datafile.csv")

# Display dataset summary
summary(data)

# Data visualization
# Select columns for correlation analysis
selected_cols <- c("Ever tobacco users (%)", "Current tobacco users (%)", "Ever tobacco smokers (%)", "Current tobacco smokers (%)")

# Calculate correlation matrix
correlation_matrix <- cor(data[, selected_cols])

# Print correlation matrix
print(correlation_matrix)

# Perform comparative analysis between different areas or regions based on smoking behaviors

# Calculate average prevalence of ever smokers and current smokers by State/UT
average_smoking_behaviors <- data %>%
  group_by(State_UT) %>%
  summarise(avg_ever_smokers = mean(`Ever tobacco smokers (%)`, na.rm = TRUE),
            avg_current_smokers = mean(`Current tobacco smokers (%)`, na.rm = TRUE))

# Melt the data for easier plotting
melted_data <- melt(average_smoking_behaviors, id.vars = "State_UT")

# Plot the comparative analysis for ever smokers
ggplot(subset(melted_data, variable == "avg_ever_smokers"), aes(x = reorder(State_UT, value), y = value)) +
  geom_bar(stat = "identity", fill = "skyblue", color = "black") +
  labs(title = "Average Prevalence of Ever Smokers by State/UT",
       x = "State/UT", y = "Average Prevalence (%)") +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1))

# Plot the comparative analysis for current smokers
ggplot(subset(melted_data, variable == "avg_current_smokers"), aes(x = reorder(State_UT, value), y = value)) +
  geom_bar(stat = "identity", fill = "salmon", color = "black") +
  labs(title = "Average Prevalence of Current Smokers by State/UT",
       x = "State/UT", y = "Average Prevalence (%)") +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1))

# Data visualization - Bar plot for Ever tobacco users by State/UT
ggplot(data, aes(x = State_UT, y = `Ever tobacco users (%)`, fill = State_UT)) +
  geom_bar(stat = "identity") +
  labs(title = "Prevalence of Ever Tobacco Users by State/UT",
       x = "State/UT", y = "Ever Tobacco Users (%)") +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1))

# Correlation analysis
correlation_matrix <- cor(select_if(data, is.numeric))

# Calculate summary statistics by region
region_summary <- data %>%
  group_by(State_UT) %>%
  summarise(avg_tobacco_users = mean(`Ever tobacco users (%)`),
            avg_smokers = mean(`Ever tobacco smokers (%)`),
            avg_cigarette_users = mean(`Ever cigarette users (%)`))

ggplot(region_summary, aes(x = State_UT, y = avg_tobacco_users)) +
  geom_bar(stat = "identity", fill = "red") +
  labs(title = "Average Tobacco Users by Region",
       x = "Region", y = "Average Tobacco Users (%)") +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1))

# Plot average smokers by region
ggplot(region_summary, aes(x = State_UT, y = avg_smokers)) +
  geom_bar(stat = "identity", fill = "salmon") +
  labs(title = "Average Smokers by Region",
       x = "Region", y = "Average Smokers (%)") +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1))

# Plot average cigarette users by region
ggplot(region_summary, aes(x = State_UT, y = avg_cigarette_users)) +
  geom_bar(stat = "identity", fill = "orange") +
  labs(title = "Average Cigarette Users by Region",
       x = "Region", y = "Average Cigarette Users (%)") +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1))

# Create a contingency table for the two categorical variables
contingency_table <- table(data$`Exposure to tobacco smoke at home/public place (%)`, data$`Exposure to tobacco smoke inside any enclosed public places  (%)`)

# Perform chi-square test
chi_square_result <- chisq.test(contingency_table)

# Print the chi-square test result
print("Chi-square Test Result:")
print(chi_square_result)

# Fit multiple linear regression model
regression_model <- lm(`Ever tobacco users (%)` ~ ., data = regression_data)

# Summary of regression model
summary(regression_model)

# Set smaller margins
par(mar = c(4, 4, 2, 2))  # Set the bottom, left, top, and right margins

# Plot diagnostic plots for regression model
par(mfrow = c(2, 2))  # Set up a 2x2 grid for plots

# Residuals vs Fitted values
plot(regression_model, which = 1)

# Normal Q-Q plot
plot(regression_model, which = 2)

# Scale-Location plot (square root of standardized residuals vs fitted values)
plot(regression_model, which = 3)

# Residuals vs Leverage
plot(regression_model, which = 5)

# Select relevant columns for clustering (you may need to preprocess the data as required)
selected_data <- data[, c("Ever tobacco users (%)", "Current tobacco users (%)", "Ever cigarette users (%)", "Ever bidi users (%)", "Ever smokeless tobacco users (%)")]

# Perform hierarchical clustering
distance_matrix <- dist(selected_data, method = "euclidean")  # Calculate distance matrix
hierarchical_cluster <- hclust(distance_matrix, method = "ward.D")  # Perform hierarchical clustering

# Visualize the dendrogram
plot(hierarchical_cluster, hang = -1, cex = 0.6)  # Adjust hang and cex parameters for better visualization

# Cut the dendrogram to create clusters
num_clusters <- 3  # Choose the number of clusters
clusters <- cutree(hierarchical_cluster, k = num_clusters)

# Add cluster labels to the original data
data_with_clusters <- cbind(data, Cluster = clusters)

# Plot clusters
ggplot(data_with_clusters, aes(x = `Ever tobacco users (%)`, y = `Current tobacco users (%)`, color = as.factor(Cluster))) +
  geom_point() +
  labs(title = "Clustering of States/UTs based on Tobacco Use Patterns", x = "Ever tobacco users (%)", y = "Current tobacco users (%)") +
  scale_color_discrete(name = "Cluster")  # Adjust legend title if necessary

# Sample data (replace this with your actual data)
data <- data.frame(
  State_UT = c("Kerala", "Karnataka", "Gujrat", "Meghalaya", "Manipur"),
  Tobacco_Usage_Rate = c(9.3, 2.6, 8.8, 35.4, 22.4)
)

# Plot chloropleth map of tobacco usage rate
ggplot(data, aes(x = reorder(State_UT, Tobacco_Usage_Rate), y = Tobacco_Usage_Rate, fill = Tobacco_Usage_Rate)) +
  geom_bar(stat = "identity", color = "black") +
  labs(title = "Tobacco Usage Rate Across States/UTs",
       x = "State/UT", y = "Tobacco Usage Rate (%)") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

