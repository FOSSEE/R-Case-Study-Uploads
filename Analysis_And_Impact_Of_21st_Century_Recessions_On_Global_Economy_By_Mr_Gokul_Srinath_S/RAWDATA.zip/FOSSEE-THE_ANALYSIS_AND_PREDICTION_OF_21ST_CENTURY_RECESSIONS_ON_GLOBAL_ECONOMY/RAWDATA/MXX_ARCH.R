library(quantmod)
MXX <- getSymbols("^MXX", from="2000-01-01",auto.assign = FALSE)[,6]
MXX_ret <- na.omit(diff(log(MXX)))
library(zoo)
roll_mean <- na.omit(rollapply(MXX_ret, 20, mean))
roll_sd <- na.omit(rollapply(MXX_ret, 20, sd))
MXX_mean_vol <- merge(roll_mean, roll_sd)
colnames(MXX_mean_vol) <- c("roll_mean", "roll_sd")
plot(MXX_mean_vol)

MXX13 <- getSymbols("^MXX", from="2013-01-01",auto.assign = FALSE)[,6]
MXX_ret13 <- na.omit(diff(log(MXX13)))
colnames(MXX_ret13) <- c("r")
library(FinTS)
ArchTest(MXX_ret13$r)

library(fGarch)
arch.fit <- garchFit(~garch(1,0), data = MXX_ret13$r, trace = F)
summary(arch.fit)


library(FinTS)
library(rugarch)

EMXXec1=ugarchspec(variance.model= list(model= "sGARCH", garchOrder= c(1, 0), 
                                           submodel= NULL, external.regressors= NULL, variance.targeting= FALSE), 
                      mean.model= list(armaOrder= c(0, 0), include.mean= TRUE, archm= FALSE, 
                                       archpow= 0, arfima= FALSE, external.regressors= NULL, archex= FALSE), 
                      distribution.model= "norm", start.pars= list(), fixed.pars= list())

#Running the ARCH model with the MXXecifications:
arch1<- ugarchfit(spec=Espec2, data=MXX_ret13$r)

arch1

garch.fit <- garchFit(~garch(1,1), data = MXX_ret13$r, trace = F)
summary(garch.fit)



predict(garch.fit, n.ahead=5, plot=TRUE)
