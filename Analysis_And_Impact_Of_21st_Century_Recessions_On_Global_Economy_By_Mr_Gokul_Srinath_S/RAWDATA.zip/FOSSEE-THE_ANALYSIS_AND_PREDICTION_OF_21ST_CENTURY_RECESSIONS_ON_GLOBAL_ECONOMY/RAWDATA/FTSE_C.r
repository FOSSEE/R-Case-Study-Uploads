#FTSE
suppressPackageStartupMessages(library(lubridate))
# enhanced summary statistics
suppressPackageStartupMessages(library(fBasics))
# coefficients significance tests
suppressPackageStartupMessages(library(lmtest))
# unit rooit test
suppressPackageStartupMessages(library(urca))
# visualization
suppressPackageStartupMessages(library(ggplot2))
# getting financial data
suppressPackageStartupMessages(library(quantmod))
# calculating returns
suppressPackageStartupMessages(library(PerformanceAnalytics))
# GARCH modeling
suppressPackageStartupMessages(library(rugarch))
# ARCH test
suppressPackageStartupMessages(library(FinTS))
# ARMA modeling
suppressPackageStartupMessages(library(forecast))
# structural changes
suppressPackageStartupMessages(library(strucchange))
# ARMA order identification
suppressPackageStartupMessages(library(TSA))
library(tseries)
library(timeSeries)
library(xts)
library(pastecs)
library(readxl)
library(zoo)
FTSE_test <- read.csv("FTSE.CSV")
head(FTSE_test)
FTSE = getSymbols('^FTSE', from='2019-06-01', to='2020-06-01',auto.assign = FALSE)
FTSE=na.omit(FTSE)
FTSE_prices = FTSE[,4]
head(FTSE_prices)
tail(FTSE_prices)
chartSeries(FTSE, type = "bars", theme="white",main="FTSE Index")
plot(FTSE, type='l', col=4, main="Time series Plot of FTSE", xlab='Date: from February 7, 2005 to August, 2022', ylab='Index')  
autoplot(FTSE_prices,main="FTSE")

# Augmented Dickey-Fuller Test
adf.test(FTSE_test$Close)


acf(FTSE_prices)


FTSE_return <- CalculateReturns(FTSE_prices, method = "log")
FTSE_return <- na.omit(FTSE_return)
plot(FTSE_return,main='FTSE return', xlab='Date', ylab='Log(Return)')


diff_price = diff(FTSE_prices)
diff_price = na.omit(diff_price)
plot(diff_price, type="l",main="1st order differencing of FTSE ",ylab="Price Differences",xlab="Days")

adf.test(diff_price,alternative="stationary")

acf(diff_price)
pacf(diff_price)


ARIMA<-auto.arima((diff_price), seasonal=FALSE)
ARIMA
model <- Arima(FTSE_prices,order=c(0,1,0),include.constant=T)
model

checkresiduals(model)

plot(forecast(model,h=500),main="FTSE During the Covid-19 Recession",ylab="Price",xlab="Date")

arima_forecast = forecast(model,h=500,level=99)
summary(arima_forecast)



