library(quantmod)
SP <- getSymbols("^GSPC", from="2000-01-01",auto.assign = FALSE)[,6]
SP_ret <- na.omit(diff(log(SP)))
library(zoo)
roll_mean <- na.omit(rollapply(SP_ret, 20, mean))
roll_sd <- na.omit(rollapply(SP_ret, 20, sd))
SP_mean_vol <- merge(roll_mean, roll_sd)
colnames(SP_mean_vol) <- c("roll_mean", "roll_sd")
plot(SP_mean_vol)

SP13 <- getSymbols("^GSPC", from="2013-01-01",auto.assign = FALSE)[,6]
SP_ret13 <- na.omit(diff(log(SP13)))
colnames(SP_ret13) <- c("r")
library(FinTS)
ArchTest(SP_ret13$r)

library(fGarch)
arch.fit <- garchFit(~garch(1,0), data = SP_ret13$r, trace = F)
summary(arch.fit)


library(FinTS)
library(rugarch)

Espec1=ugarchspec(variance.model= list(model= "sGARCH", garchOrder= c(1, 0), 
                                       submodel= NULL, external.regressors= NULL, variance.targeting= FALSE), 
                  mean.model= list(armaOrder= c(0, 0), include.mean= TRUE, archm= FALSE, 
                                   archpow= 0, arfima= FALSE, external.regressors= NULL, archex= FALSE), 
                  distribution.model= "norm", start.pars= list(), fixed.pars= list())

#Running the ARCH model with the specifications:
arch1<- ugarchfit(spec=Espec1, data=SP_ret13$r)

arch1

garch.fit <- garchFit(~garch(1,1), data = SP_ret13$r, trace = F)
summary(garch.fit)



predict(garch.fit, n.ahead=5, plot=TRUE)
