library(readxl)
-------------------------#NIFTY--------------------------------
#for nifty 
nifty=read.csv('NIFTY.csv')
nifty.timeseries <- ts(nifty,start = c(2012,1),frequency = 12)
# Print the timeseries data.
print(nifty.timeseries)
# Give the chart file a name.
png(file = "nifty.png")
# Plot a graph of the time series.
plot(nifty.timeseries)
# Save the file.
dev.off()
# Printing the first few rows of the dataset
head(nifty)
# Returns the variable name of the data
names(nifty)
# Returns Dimensions of the data
dim(nifty)
# Returns the Structure of the data
str(nifty)
# Returns the Summary Statistics of the data
summary(nifty)
# Count the Numbers
colSums(is.na(nifty))
# Install & load tidyr
install.packages("tidyr")              
library("tidyr")
# Reshape data frame
nifty_long <- pivot_longer(nifty, c("Close","Open","High","Low"))
# Install GGally package
install.packages("GGally")           
library("GGally")
# Draw histograms
ggplot(nifty_long,                  
       aes(x = value)) +
  geom_histogram() + 
  facet_wrap(name ~ ., scales = "free")



