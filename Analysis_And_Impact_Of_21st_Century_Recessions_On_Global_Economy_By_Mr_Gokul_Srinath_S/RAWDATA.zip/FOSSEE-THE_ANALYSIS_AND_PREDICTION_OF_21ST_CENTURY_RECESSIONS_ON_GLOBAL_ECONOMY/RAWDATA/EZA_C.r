#EZA
suppressPackageStartupMessages(library(lubridate))
# enhanced summary statistics
suppressPackageStartupMessages(library(fBasics))
# coefficients significance tests
suppressPackageStartupMessages(library(lmtest))
# unit rooit test
suppressPackageStartupMessages(library(urca))
# visualization
suppressPackageStartupMessages(library(ggplot2))
# getting financial data
suppressPackageStartupMessages(library(quantmod))
# calculating returns
suppressPackageStartupMessages(library(PerformanceAnalytics))
# GARCH modeling
suppressPackageStartupMessages(library(rugarch))
# ARCH test
suppressPackageStartupMessages(library(FinTS))
# ARMA modeling
suppressPackageStartupMessages(library(forecast))
# structural changes
suppressPackageStartupMessages(library(strucchange))
# ARMA order identification
suppressPackageStartupMessages(library(TSA))
library(tseries)
library(timeSeries)
library(xts)
library(pastecs)
library(readxl)
library(zoo)
EZA_test <- read.csv("EZA.csv")
head(EZA_test)
EZA = getSymbols('EZA', from='2019-06-01', to='2020-06-01',auto.assign = FALSE)
EZA=na.omit(EZA)
EZA_prices = EZA[,4]
head(EZA_prices)
tail(EZA_prices)
chartSeries(EZA, type = "bars", theme="white",main="EZA Index")
plot(EZA, type='l', col=4, main="Time series Plot of EZA", xlab='Date: from February 7, 2005 to August, 2022', ylab='Index')  
autoplot(EZA_prices,main="EZA")

# Augmented Dickey-Fuller Test
adf.test(EZA_test$Close)


acf(EZA_prices)


EZA_return <- CalculateReturns(EZA_prices, method = "log")
EZA_return <- na.omit(EZA_return)
plot(EZA_return,main='EZA return', xlab='Date', ylab='Log(Return)')


diff_price = diff(EZA_prices)
diff_price = na.omit(diff_price)
plot(diff_price, type="l",main="1st order differencing of EZA ",ylab="Price Differences",xlab="Days")

adf.test(diff_price,alternative="stationary")

acf(diff_price)
pacf(diff_price)


ARIMA<-auto.arima((diff_price), seasonal=FALSE)
ARIMA
model <- Arima(EZA_prices,order=c(0,1,0),include.constant=T)
model

checkresiduals(model)

plot(forecast(model,h=100),main="EZA During the Covid-19 Recession",ylab="Price",xlab="Date")

arima_forecast = forecast(model,h=100,level=99)
summary(arima_forecast)



