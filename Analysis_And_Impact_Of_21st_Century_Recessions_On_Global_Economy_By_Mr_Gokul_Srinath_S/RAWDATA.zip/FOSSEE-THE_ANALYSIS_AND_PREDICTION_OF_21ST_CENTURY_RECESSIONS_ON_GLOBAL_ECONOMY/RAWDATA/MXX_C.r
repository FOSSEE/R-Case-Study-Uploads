#MXX
suppressPackageStartupMessages(library(lubridate))
# enhanced summary statistics
suppressPackageStartupMessages(library(fBasics))
# coefficients significance tests
suppressPackageStartupMessages(library(lmtest))
# unit rooit test
suppressPackageStartupMessages(library(urca))
# visualization
suppressPackageStartupMessages(library(ggplot2))
# getting financial data
suppressPackageStartupMessages(library(quantmod))
# calculating returns
suppressPackageStartupMessages(library(PerformanceAnalytics))
# GARCH modeling
suppressPackageStartupMessages(library(rugarch))
# ARCH test
suppressPackageStartupMessages(library(FinTS))
# ARMA modeling
suppressPackageStartupMessages(library(forecast))
# structural changes
suppressPackageStartupMessages(library(strucchange))
# ARMA order identification
suppressPackageStartupMessages(library(TSA))
library(tseries)
library(timeSeries)
library(xts)
library(pastecs)
library(readxl)
library(zoo)
MXX_test <- read.csv("MXX.CSV")
head(MXX_test)
MXX = getSymbols('^MXX', from='2019-06-01', to='2020-06-01',auto.assign = FALSE)
MXX=na.omit(MXX)
MXX_prices = MXX[,4]
head(MXX_prices)
tail(MXX_prices)
chartSeries(MXX, type = "bars", theme="white",main="MXX Index")
plot(MXX, type='l', col=4, main="Time series Plot of MXX", xlab='Date: from February 7, 2005 to August, 2022', ylab='Index')  
autoplot(MXX_prices,main="MXX")

# Augmented Dickey-Fuller Test
adf.test(MXX_test$Close)


acf(MXX_prices)


MXX_return <- CalculateReturns(MXX_prices, method = "log")
MXX_return <- na.omit(MXX_return)
plot(MXX_return,main='MXX return', xlab='Date', ylab='Log(Return)')


diff_price = diff(MXX_prices)
diff_price = na.omit(diff_price)
plot(diff_price, type="l",main="1st order differencing of MXX ",ylab="Price Differences",xlab="Days")

adf.test(diff_price,alternative="stationary")

acf(diff_price)
pacf(diff_price)


ARIMA<-auto.arima((diff_price), seasonal=FALSE)
ARIMA
model <- Arima(MXX_prices,order=c(0,1,0),include.constant=T)
model

checkresiduals(model)

plot(forecast(model,h=500),main="MXX During the Covid-19 Recession",ylab="Price",xlab="Date")

arima_forecast = forecast(model,h=500,level=99)
summary(arima_forecast)



