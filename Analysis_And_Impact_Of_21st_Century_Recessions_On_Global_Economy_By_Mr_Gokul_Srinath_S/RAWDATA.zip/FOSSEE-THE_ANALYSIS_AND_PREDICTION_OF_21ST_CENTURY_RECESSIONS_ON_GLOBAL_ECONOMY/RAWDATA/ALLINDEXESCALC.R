library(quantmod)
library(highcharter)

# Fetch BBNI, BMRI, and IHSG stock prices
#CONTINENT - ASIA
NIFTY50 <- getSymbols("^NSEI",auto.assign=FALSE,from="2000-01-01",to="2021-12-31")
NIFTY50=na.omit(NIFTY50)
#CONTINENT - NORTH AMERICA
SP500 <- getSymbols("^GSPC",auto.assign=FALSE,from="2000-01-01",to="2021-12-31")
SP500=na.omit(SP500)
#CONTINENT - EUROPE
FTSE <- getSymbols("^FTSE",auto.assign=FALSE,from="2000-01-01",to="2021-12-31")
price_ihsg=na.omit(FTSE)
#CONTINENT - SOUTH AMERICA
SAm <- getSymbols("^MXX",auto.assign=FALSE,from="2000-01-01",to="2021-12-31")
price_ihsg=na.omit(SA)
#CONTINENT - AFRICA
SA <- getSymbols("EZA",auto.assign=FALSE,from="2000-01-01",to="2021-12-31")
price_ihsg=na.omit(SA)
#CONTINENT - AUSTRALIA
AUS <- getSymbols("EWA",auto.assign=FALSE,from="2001-01-01",to="2021-12-31")
price_ihsg=na.omit(AUS)


# Compare the stock prices
highchart(type="stock") %>% 
 
  hc_add_series(Cl(NIFTY50), name="NIFTY50") %>% 
  hc_add_series(Cl(SP500), name="SP500") %>% 
  hc_add_series(Cl(FTSE), name="FTSE") %>% 
  hc_add_series(Cl(SAm), name="MXX") %>% 
  hc_add_series(Cl(SA), name="EZA") %>% 
  hc_add_series(Cl(AUS), name="EWA") %>% 
  hc_title(text="<b>NIFTY50 vs SP500 vs FTSE  Closing Price</b>")

#NIFTY50 - ASIA
return_NIFTY50 <- dailyReturn(Cl(NIFTY50))
returnsNIFTY50 <- data.frame(return_NIFTY50)
names(returnsNIFTY50) <- c("return_NIFTY50")
returnsN <- as.xts(returnsNIFTY50)
library(PerformanceAnalytics)
charts.PerformanceSummary(returnsN,main="YEARLY Returns of NIFTY50")

#S&P500 - North America
return_SP500 <- dailyReturn(Cl(SP500))
returnsSP500 <- data.frame(return_SP500)
names(returnsSP500) <- c("return_SP500")
returnsSP <- as.xts(returnsSP500)
# Plot the returns
library(PerformanceAnalytics)
charts.PerformanceSummary(returnsSP,main="YEARLY Returns of S&P 500")

#FTSE - Eurpoe
return_FTSE <- dailyReturn(Cl(FTSE))
returnsFTSE <- data.frame(return_FTSE)
names(returnsFTSE) <- c("return_FTSE")
returnsLondon <- as.xts(returnsFTSE)
library(PerformanceAnalytics)
charts.PerformanceSummary(returnsLondon,main="YEARLY Returns of FTSE")

#MXX - South America
return_SAm <- dailyReturn(Cl(SAm))
returnsSAm <- data.frame(return_SAm)
names(returnsSAm) <- c("return_SAm")
returnsSoAm <- as.xts(returnsSAm)
library(PerformanceAnalytics)
charts.PerformanceSummary(returnsSoAm,main="YEARLY Returns of MXX")

#EZA - Africa

return_SA <- dailyReturn(Cl(SA))
returnsSA <- data.frame(return_SA)
names(returnsSA) <- c("return_SA")
returnsAfrica <- as.xts(returnsSA)
library(PerformanceAnalytics)
charts.PerformanceSummary(returnsAfrica,main="YEARLY Returns of EZA")


#EWA - Australia
return_AUS <- dailyReturn(Cl(AUS))
returnsAUS <- data.frame(return_AUS)
names(returnsSA) <- c("return_AUS")
returnsAussi <- as.xts(returnsAUS)
library(PerformanceAnalytics)
charts.PerformanceSummary(returnsAussi,main="YEARLY Returns of EWA")