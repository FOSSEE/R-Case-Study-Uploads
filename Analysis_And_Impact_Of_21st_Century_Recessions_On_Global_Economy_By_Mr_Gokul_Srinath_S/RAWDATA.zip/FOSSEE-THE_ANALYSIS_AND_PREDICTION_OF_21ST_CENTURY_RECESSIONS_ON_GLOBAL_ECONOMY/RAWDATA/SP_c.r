#SP50
suppressPackageStartupMessages(library(lubridate))
# enhanced summary statistics
suppressPackageStartupMessages(library(fBasics))
# coefficients significance tests
suppressPackageStartupMessages(library(lmtest))
# unit rooit test
suppressPackageStartupMessages(library(urca))
# visualization
suppressPackageStartupMessages(library(ggplot2))
# getting financial data
suppressPackageStartupMessages(library(quantmod))
# calculating returns
suppressPackageStartupMessages(library(PerformanceAnalytics))
# GARCH modeling
suppressPackageStartupMessages(library(rugarch))
# ARCH test
suppressPackageStartupMessages(library(FinTS))
# ARMA modeling
suppressPackageStartupMessages(library(forecast))
# structural changes
suppressPackageStartupMessages(library(strucchange))
# ARMA order identification
suppressPackageStartupMessages(library(TSA))
library(tseries)
library(timeSeries)
library(xts)
library(pastecs)
library(readxl)
library(zoo)
SP_test <- read.csv("SP500.CSV")
head(SP_test)
SP = getSymbols('^GSPC', from='2019-09-01', to='2020-03-20',auto.assign = FALSE)
SP=na.omit(SP)
SP_prices = SP[,4]
head(SP_prices)
tail(SP_prices)
chartSeries(SP, type = "bars", theme="white",main="SP500 Index")
plot(SP, type='l', col=4, main="Time series Plot of SP500", xlab='Date: from February 7, 2005 to August, 2022', ylab='Index')  
autoplot(SP_prices,main="SP500")

# Augmented Dickey-Fuller Test
adf.test(SP_test$Close)


acf(SP_prices)


SP_return <- CalculateReturns(SP_prices, method = "log")
SP_return <- na.omit(SP_return)
plot(SP_return,main='SP return', xlab='Date', ylab='Log(Return)')


diff_price = diff(SP_prices)
diff_price = na.omit(diff_price)
plot(diff_price, type="l",main="1st order differencing of SP500 ",ylab="Price Differences",xlab="Days")

adf.test(diff_price,alternative="stationary")

acf(diff_price)
pacf(diff_price)


ARIMA<-auto.arima((diff_price), seasonal=FALSE)
ARIMA
model <- Arima(SP_prices,order=c(0,1,0),include.constant=T)
model

checkresiduals(model)

plot(forecast(model,h=100),main="SP500 During the Covid-19 Recession",ylab="Price",xlab="Date")

arima_forecast = forecast(model,h=100,level=99)
summary(arima_forecast)



