#NIFTY50
suppressPackageStartupMessages(library(lubridate))
# enhanced summary statistics
suppressPackageStartupMessages(library(fBasics))
# coefficients significance tests
suppressPackageStartupMessages(library(lmtest))
# unit rooit test
suppressPackageStartupMessages(library(urca))
# visualization
suppressPackageStartupMessages(library(ggplot2))
# getting financial data
suppressPackageStartupMessages(library(quantmod))
# calculating returns
suppressPackageStartupMessages(library(PerformanceAnalytics))
# GARCH modeling
suppressPackageStartupMessages(library(rugarch))
# ARCH test
suppressPackageStartupMessages(library(FinTS))
# ARMA modeling
suppressPackageStartupMessages(library(forecast))
# structural changes
suppressPackageStartupMessages(library(strucchange))
# ARMA order identification
suppressPackageStartupMessages(library(TSA))
library(tseries)
library(timeSeries)
library(xts)
library(pastecs)
library(readxl)
library(zoo)
nifty_test <- read.csv("NIFTY.CSV")
head(nifty_test)
NIFTY = getSymbols('^NSEI', from='2022-01-01', to='2020-08-01',auto.assign = FALSE)
NIFTY=na.omit(NIFTY)
nifty_prices = NIFTY[,4]
head(nifty_prices)
tail(nifty_prices)
chartSeries(NIFTY, type = "bars", theme="white",main="NIFTY Index")
plot(NIFTY, type='l', col=4, main="Time series Plot of NIFTY50", xlab='Date: from February 7, 2005 to August, 2022', ylab='Index')  
autoplot(nifty_prices,main="NIFTY50")

# Augmented Dickey-Fuller Test
adf.test(nifty_test$Close)


acf(nifty_prices)


NIFTY_return <- CalculateReturns(nifty_prices, method = "log")
NIFTY_return <- na.omit(NIFTY_return)
plot(NIFTY_return,main='NIFTY return', xlab='Date', ylab='Log(Return)')


diff_price = diff(nifty_prices)
diff_price = na.omit(diff_price)
plot(diff_price, type="l",main="1st order differencing of NIFTY50 ",ylab="Price Differences",xlab="Days")

adf.test(diff_price,alternative="stationary")

acf(diff_price)
pacf(diff_price)


ARIMA<-auto.arima((diff_price), seasonal=FALSE)
ARIMA
model <- Arima(nifty_prices,order=c(0,1,0),include.constant=T)
model

checkresiduals(model)

plot(forecast(model,h=500),main="NIFTY50 During the Covid-19 Recession",ylab="Price",xlab="Date")

arima_forecast = forecast(model,h=500,level=99)
summary(arima_forecast)



