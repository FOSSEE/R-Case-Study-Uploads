install.packages('tidyverse')
library(tidyverse)
coin_Bitcoin <- read.csv("E:/R_Scripts/Case study/coin_Bitcoin.csv")
coin_Dogecoin <- read.csv('E:/R_Scripts/Case study/coin_Dogecoin.csv')
coin_Ethereum <- read.csv('E:/R_Scripts/Case study/coin_Ethereum.csv')

crypto_coins_initial <- rbind(coin_Ethereum, coin_Dogecoin)
crypto_coins_merged <- rbind(crypto_coins_initial, coin_Bitcoin)

str(crypto_coins_merged)
colnames(crypto_coins_merged)
head(crypto_coins_merged)

ggplot(data = crypto_coins_merged) +
  geom_point(aes(x=Date,y=Close, color=Name)) +
  labs(title="Popular Crypto Prices Over Time", y="Price in USD", x="Time") +
  facet_wrap(~ Name)

ggplot(data = coin_Dogecoin, aes(x=Date,y=Close)) +
  geom_point() +
  labs(title="Dogecoin", y="Price in USD", x="Time") 


ggplot(data = coin_Ethereum, aes(x=Date,y=Close)) +
  geom_point()+
  geom_smooth(aes(group= -1), method ='gam', formula =y ~ s(x) ) +
  labs(title="Ethereum", y="Price in USD", x="Time") 

ggplot(data = crypto_coins_initial,aes(x=Volume,y=Close, color=Name)) +
  geom_point() +
  geom_smooth(aes(group= -1), method ='gam', formula =y ~ s(x) ) +
  labs(title="Price vs Volume", y="Price in USD", x="Volume traded per Day") +
  facet_wrap(~ Name)

ggplot(data = coin_Bitcoin,aes(x=Volume,y=Close)) +
  geom_point() +
  geom_smooth(aes(group= -1), method ='gam', formula =y ~ s(x) ) +
  labs(title="Price vs Volume", y="Price in USD", x="Volume traded per Day") +
  facet_wrap(~ Name)

ggplot(data = coin_Bitcoin,aes(x=Volume,y=Close)) +
  geom_point() +
  geom_smooth(aes(group= -1), method ='lm') +
  labs(title="Price vs Volume", y="Price in USD", x="Volume traded per Day") +
  facet_wrap(~ Name)

ggplot(data = coin_Ethereum,aes(x=Date,y=Volume)) +
  geom_point() +
  geom_smooth(aes(group= -1), method ='gam', formula =y ~ s(x) ) +
  labs(title="Trade Volume over Time", y="Volume Traded per Day", x="Time") +
  facet_wrap(~ Name)

ggplot(data = coin_Dogecoin,aes(x=Date,y=Volume)) +
  geom_point() +
  geom_smooth(aes(group= -1), method ='gam', formula =y ~ s(x) ) +
  labs(title="Trade Volume over Time", y="Volume Traded per Day", x="Time") +
  facet_wrap(~ Name)

ggplot(data = coin_Bitcoin,aes(x=Date,y=Volume)) +
  geom_point() +
  geom_smooth(aes(group= -1), method ='gam', formula =y ~ s(x) ) +
  labs(title="Trade Volume over Time", y="Volume Traded per Day", x="Time") +
  facet_wrap(~ Name)

