# dates manipulation
suppressPackageStartupMessages(library(lubridate))
# enhanced summary statistics
suppressPackageStartupMessages(library(fBasics))
# coefficients significance tests
suppressPackageStartupMessages(library(lmtest))
# unit rooit test
suppressPackageStartupMessages(library(urca))
# visualization
suppressPackageStartupMessages(library(ggplot2))
# getting financial data
suppressPackageStartupMessages(library(quantmod))
# calculating returns
suppressPackageStartupMessages(library(PerformanceAnalytics))
# GARCH modeling
suppressPackageStartupMessages(library(rugarch))
# ARCH test
suppressPackageStartupMessages(library(FinTS))
# ARMA modeling
suppressPackageStartupMessages(library(forecast))
# structural changes
suppressPackageStartupMessages(library(strucchange))
# ARMA order identification
suppressPackageStartupMessages(library(TSA))
library(tseries)
library(timeSeries)
library(xts)
library(pastecs)
library(readxl)
library(zoo)


library(readxl)
nifty=read.csv('NSEI.csv')
snp=read.csv('S&P.csv')

nifty.timeseries <- ts(nifty,start = c(2012,1),frequency = 12)
snp.timeseries <- ts(snp,start = c(2012,1),frequency = 12)

# Print the timeseries data.
print(nifty.timeseries) 
print(snp.timeseries)

# Give the chart file a name.
png(file = "nifty.png")
png(file = "s&p.png")

# Plot a graph of the time series.
plot(nifty.timeseries)
plot(snp.timeseries)


# Save the file.
dev.off()


# Printing the first few rows of the dataset
head(nifty)
head(snp)

# Returns the variable name of the data
names(nifty)
names(snp)

# Returns Dimensions of the data
dim(nifty)
dim(snp)

# Returns the Structure of the data
str(nifty)
str(snp)

# Returns the Summary Statistics of the data
summary(nifty)
summary(snp)



# Install & load tidyr
install.packages("tidyr")              
library("tidyr")

# Reshape data frame
nifty_long <- pivot_longer(nifty, c("Open", "High", "Low", "Close"))
snp_long <- pivot_longer(snp, c("Open", "High", "Low", "Close"))

# Install GGally package
install.packages("GGally")           
library("GGally")

# Draw boxplots
ggplot(nifty_long,aes(x = value,fill = name)) + geom_boxplot()


# Draw histograms
ggplot(nifty_long,                    # Draw histograms
       aes(x = value)) +
  geom_histogram() + 
  facet_wrap(name ~ ., scales = "free")



NIFTY = getSymbols('^NSEI', from='2022-01-01', to='2022-04-26',auto.assign = FALSE)
NIFTY = na.omit(NIFTY)
head(NIFTY)

S_P = getSymbols('^GSPC', from='2022-01-01', to='2022-04-26',auto.assign = FALSE)
S_P = na.omit(S_P)
head(S_P)


# Select the relevant close price series for NIFTY50 data
stock_prices = NIFTY[,4]
head(stock_prices)
tail(stock_prices)
chartSeries(NIFTY, type = "bars", theme="white",main="NIFTY 50")

# Select the relevant close price series for S&P500 data
stock_prices1 = S_P[,4]
head(stock_prices1)
tail(stock_prices1)
chartSeries(S_P, type = "bars", theme="white",main="S&P500")

# for a basic plot, all you need is
plot(NIFTY, type='l', col=4, main="Time series Plot of NIFTY50", xlab='Date: from 2022-01-01 to 2022-04-26', ylab='Stock')  
plot(S_P, type='l', col=4, main="Time series Plot of S&P500", xlab='Date: from 2022-01-01 to 2022-04-26', ylab='Stock')  


autoplot(stock_prices,main="NIFTY50")
autoplot(stock_prices1,main="S&P500")

#Identifying non-stationary series for NIFTY50
acf(NIFTY)

NIFTY_return <- CalculateReturns(stock_prices, method = "log")
NIFTY_return <- na.omit(NIFTY_return)

head(NIFTY_return)
tail(NIFTY_return)

plot(NIFTY_return,main='NIFTY return ', xlab='Date', ylab='Log(Return)')


#Identifying non-stationary series for S&P500
acf(S_P)

S_P_return <- CalculateReturns(stock_prices1, method = "log")
S_P_return <- na.omit(S_P_return)

head(S_P_return)
tail(S_P_return)

plot(S_P_return,main='S&P500 return ', xlab='Date', ylab='Log(Return)')


# Time Series Differencing for NIFTY50
diff_price = diff(stock_prices)
diff_price = na.omit(diff_price)
plot(diff_price, type="l",main="1st order diff of NIFTY",ylab="Price Differences",xlab="Days")

# Apply Unit Root Tests on Differenced data
# Augmented Dickey-Fuller Test ADF
adf.test(diff_price,alternative="stationary")

# ARIMA Models Specification
# Normal and Partial Autocorrelation Functions ACF & PACF
acf(diff_price)
pacf(diff_price)

#Checking using auto.arima
ARIMA<-auto.arima((diff_price), seasonal=FALSE)
ARIMA

#Implement ARIMA (0,1,0) model
model <- Arima(stock_prices,order=c(0,1,0),include.constant=T)
model

#Check Residuals for ARIMA (0,1,0) model
checkresiduals(model)

# Multi-Steps Forecast
plot(forecast(model,h=5),main="ARIMA(0,1,0) using Multi-Steps Forecast for NIFTY50",ylab="Price",xlab="Date")

# Time Series Differencing for S&P500
diff_price1 = diff(stock_prices1)
diff_price1 = na.omit(diff_price1)
plot(diff_price1, type="l",main="1st order diff of S&P500",ylab="Price Differences",xlab="Days")

# Apply Unit Root Tests on Differenced data
# Augmented Dickey-Fuller Test ADF
adf.test(diff_price1,alternative="stationary")

# ARIMA Models Specification
# Normal and Partial Autocorrelation Functions ACF & PACF
acf(diff_price1)
pacf(diff_price1)

#Checking using auto.arima
ARIMA1<-auto.arima((diff_price1), seasonal=FALSE)
ARIMA1

#Implement ARIMA (0,1,0) model
model1 <- Arima(stock_prices1,order=c(0,1,0),include.constant=T)
model1

#Check Residuals for ARIMA (0,1,0) model
checkresiduals(model1)

# Multi-Steps Forecast
plot(forecast(model1,h=5),main="ARIMA(0,1,0) using Multi-Steps Forecast for S&P500",ylab="Price",xlab="Date")



library(ggplot2)
library(zoo)
library(quantmod)
library(xts)
library(PerformanceAnalytics)
library(rugarch)

getSymbols("^NSEI",from = "2022-01-01",to = "2022-04-26")

chartSeries(NSEI)
lreturn <- NSEI$NSEI.Close
lreturn<- na.omit(lreturn)
return <- CalculateReturns(NSEI$NSEI.Close)
return <- return[-1]
return<- na.omit(return)
autoplot(return)

hist(return)

chart.Histogram(return,
                methods = c('add.density', 'add.normal'),
                colorset = c('blue', 'green', 'red'))
chartSeries(return)


#GARCH MODEL FOR NIFTY50 DATA

s1 <- ugarchspec(variance.model=list(model="sGARCH",garchOrder=c(1,1)),
                 mean.model=list(armaOrder=c(0,0)),distribution.model="norm")
m1 <- ugarchfit(data = return, spec = s1)
m1

plot(m1, which = 'all')

s2 <-  ugarchspec(variance.model=list(model="sGARCH",garchOrder=c(1,1)),
                  mean.model=list(armaOrder=c(2,2)),distribution.model="norm")
m2 <- ugarchfit(data = return, spec = s2)
m2

plot(m2, which = 'all')

s3 <-  ugarchspec(variance.model=list(model="sGARCH",garchOrder=c(1,2)),
                  mean.model=list(armaOrder=c(2,2)),distribution.model="norm")
m3 <- ugarchfit(data = return, spec = s3)
m3

plot(m3, which = 'all')


s4 <-  ugarchspec(variance.model=list(model="sGARCH",garchOrder=c(2,1)),
                  mean.model=list(armaOrder=c(1,1)),distribution.model="norm")
m4 <- ugarchfit(data = return, spec = s4)
m4

plot(m4, which = 'all')


#use this model to forecast values for the next 30 days

s2final <-  ugarchspec(variance.model=list(model="sGARCH",garchOrder=c(1,1)),
                       mean.model=list(armaOrder=c(2,2)),distribution.model="norm")
m2final <- ugarchfit(data = return, spec = s2final)
f <- ugarchforecast(fitORspec = m2final, n.ahead = 30)
plot(fitted(f))



#Prediction
#Forecasting our predictions on actual stock price values using our model
sfinal <- s2
setfixed(sfinal) <- as.list(coef(m2))



sim <- ugarchpath(spec = sfinal,
                  m.sim = 1,
                  n.sim = 1*30,
                  rseed = 16)
plot.zoo(fitted(sim))


















