
#GARCH MODEL FOR S&P500 DATA

library(ggplot2)
library(zoo)
library(quantmod)
library(xts)
library(PerformanceAnalytics)
library(rugarch)
getSymbols("^GSPC",from = "2022-01-01",to = "2022-04-26")

chartSeries(GSPC)
lreturn <- GSPC$GSPC.Close
lreturn<- na.omit(lreturn)
return <- CalculateReturns(GSPC$GSPC.Close)
return <- return[-1]
return<- na.omit(return)
autoplot(return)

hist(return)

chart.Histogram(return,
                methods = c('add.density', 'add.normal'),
                colorset = c('blue', 'green', 'red'))
chartSeries(return)


#GARCH MODEL
s_1 <- ugarchspec(variance.model=list(model="sGARCH",garchOrder=c(1,1)),
                  mean.model=list(armaOrder=c(0,0)),distribution.model="norm")
m_1 <- ugarchfit(data = return, spec = s_1)
m_1
plot(m_1, which = 'all')

s_2 <-  ugarchspec(variance.model=list(model="sGARCH",garchOrder=c(1,1)),
                   mean.model=list(armaOrder=c(2,2)),distribution.model="norm")
m_2 <- ugarchfit(data = return, spec = s_2)
m_2


plot(m_2, which = 'all')

s_3 <-  ugarchspec(variance.model=list(model="sGARCH",garchOrder=c(1,2)),
                   mean.model=list(armaOrder=c(2,2)),distribution.model="norm")
m_3 <- ugarchfit(data = return, spec = s_3)
m_3

plot(m_3, which = 'all')


s_4 <-  ugarchspec(variance.model=list(model="sGARCH",garchOrder=c(2,1)),
                   mean.model=list(armaOrder=c(1,1)),distribution.model="norm")
m_4 <- ugarchfit(data = return, spec = s_4)
m_4

plot(m_4, which = 'all')


#use this model to forecast values for the next 30 days

s2_final <-  ugarchspec(variance.model=list(model="sGARCH",garchOrder=c(1,2)),
                        mean.model=list(armaOrder=c(2,2)),distribution.model="norm")
m2_final <- ugarchfit(data = return, spec = s2_final)
f1 <- ugarchforecast(fitORspec = m2_final, n.ahead = 30)
plot(fitted(f1))



#Prediction
#Forecasting our predictions on actual stock price values using our model
s_final <- s_2
setfixed(s_final) <- as.list(coef(m_2))



sim1 <- ugarchpath(spec = s_final,
                   m.sim = 1,
                   n.sim = 1*30,
                   rseed = 16)
plot.zoo(fitted(sim1))

