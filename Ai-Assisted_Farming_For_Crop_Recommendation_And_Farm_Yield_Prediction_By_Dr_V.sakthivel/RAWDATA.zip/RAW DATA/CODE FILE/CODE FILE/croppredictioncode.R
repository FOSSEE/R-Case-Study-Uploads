cropsuggest=read.csv("C:/Users/Eathish/Desktop/AI ASSISTED FARMING AND CROP YIELD PREDICTION/DATA FILE/TAMILNADU_CROP_PRODUCTION.csv")
head(cropsuggest)
View(cropsuggest)
table(cropsuggest$crops)##to check how many categorical variables are arranged
dim(cropsuggest)##to check the no of rows and columns
which(is.na(cropsuggest))#this check for the nan values

##this dataset doesnt have nan values

##visualization
y<-table(cropsuggest$humidity,cropsuggest$rainfall)#table between distribution of humidity vs Rainfall
barplot(y,col = "blue",xlab="humidity",ylab = "Rainfall",main="frequencies of Humidity VS Rainfall")#barplot of frequencies of humidity and rainfall
pairs(~Phosphorus+Nitrogen+Potassium+ph+humidity+temperature+rainfall,data=cropsuggest)
summary(cropsuggest)

##using ggplot lets visualize the variables in dataset
library(dplyr)
library(ggplot2)
##Nitrogen vs Phosphorous
cropsuggest %>% ggplot(aes(Nitrogen, Phosphorus)) +
  geom_point(color= "blue", alpha = 0.3) +
  ggtitle("Nitrogen vs Phosphorous") +
  xlab("Nitrogen") +
  ylab("Phosphorous") +
  theme(plot.title = element_text(color="darkred",
                                  size=18,hjust = 0.5),
        axis.text.y = element_text(size=12),
        axis.text.x = element_text(size=12,hjust=.5),
        axis.title.x = element_text(size=14),
        axis.title.y = element_text(size=14))
##temperature vs rainfall
cropprod %>% ggplot(aes(temperature, rainfall)) +
  geom_point(color= "blue", alpha = 0.3) +
  ggtitle("temperature vs rainfall") +
  xlab("Temperature") +
  ylab("Rainfall") +
  theme(plot.title = element_text(color="darkgreen",
                                  size=18,hjust = 0.5),
        axis.text.y = element_text(size=12),
        axis.text.x = element_text(size=12,hjust=.5),
        axis.title.x = element_text(size=14),
        axis.title.y = element_text(size=14))
##Potassium vs ph
cropsuggest %>% ggplot(aes(Potassium, ph)) +
  geom_point(color= "red", alpha = 0.3) +
  ggtitle("Potassium vs ph") +
  xlab("Potassium") +
  ylab("ph") +
  theme(plot.title = element_text(color="darkgreen",
                                  size=18,hjust = 0.5),axis.text.y = element_text(size=12),
        axis.text.x = element_text(size=12,hjust=.5),axis.title.x = element_text(size=14),
        axis.title.y = element_text(size=14))
##Potassium vs ph
cropsuggest %>% ggplot(aes(humidity, rainfall)) +
  geom_point(color= "red", alpha = 0.3) +
  ggtitle("Humidity vs rainfall") +
  xlab("humidity") +
  ylab("rainfall") +
  theme(plot.title = element_text(color="darkgreen",
                                  size=18,hjust = 0.5),axis.text.y = element_text(size=12),
        axis.text.x = element_text(size=12,hjust=.5),axis.title.x = element_text(size=14),
        axis.title.y = element_text(size=14))

##model analysis

df <- data.frame( label = c("apple","banana", "blackgram", "chickpea", "coconut","coffee","cotton","grapes","jute","kidneybeans","lentil","maize","mango","mothbeans","mungbean","muskmelon","orange","papaya","pigeonpeas","pomegranate","rice","watermelon")) 
cropsuggest$crops <- as.numeric( factor(cropsuggest$crops) ) -1
dim(cropsuggest)
head(cropsuggest,30)
##to plot correlation plot
correlations = cor(cropsuggest)
library(corrplot)
corrplot(correlations, method="color")

##multi linear regression
# create training set indices with 80% of data
## Linear Regression
# Fit linear regression model
# put the predictors on the same scale: mean of zero and unit variance
set.seed(100)  # For reproducibility
# Create index for testing and training data
library(caret)
inTrain1 <- createDataPartition(y = cropsuggest$crops, 
                               p = 0.8, list = FALSE)
# subset  dataset to training
training1 <- cropsuggest[inTrain1,]
# subset the rest to test
testing1 <- cropsuggest[-inTrain1,]
library(dplyr)
# Size ratio of training and test dataset
message("As shown below, the training set is about 80%  and the test set is about 20% of the original data")
rbind("Training set" = nrow(training1)/nrow(cropsuggest),
      "Testing set" = nrow(testing1)/nrow(cropsuggest)) %>% 
  round(2)*100
my_lm <- train(training1[,1:7], training1[,8],
               method = "lm",
               preProc = c("center", "scale")
)
message("Linear Regression: Model performance on \n the training set")
my_lm$results[c("RMSE","Rsquared")] %>%
  round(2)
summary(my_lm)

##decision tree
library(rpart)
library(rpart.plot)
prop.table(table(training1$crops))
fit <- rpart(crops~., data = training1, method = 'class')
rpart.plot(fit, extra = 106)
predict_unseen <-predict(fit, testing1, type = 'class')
table_mat <- table(testing1$crops, predict_unseen)
table_mat
accuracy_Test <- sum(diag(table_mat)) / sum(table_mat)
print(paste('Accuracy for test', accuracy_Test))

#naive bayes
cropsuggest1=read.csv("C:/Users/Eathish/Desktop/AI ASSISTED FARMING AND CROP YIELD PREDICTION/DATA FILE/TAMILNADU_CROP_PRODUCTION.csv")
indxTrain <- createDataPartition(y = cropsuggest1$crops,p = 0.75,list = FALSE)
training1 <- cropsuggest1[indxTrain,]
testing1 <- cropsuggest1[-indxTrain,] 
prop.table(table(cropsuggest1$crops)) * 100
library(e1071)
x = training1[,-8]
y = training1$crops
model = train(x,y,'nb',trControl=trainControl(method='cv',number=10))
model
Predict <- predict(model,newdata = testing1 )
summary(Predict)
X <- varImp(model)
plot(X)

#svm
trctrl <- trainControl(method = "repeatedcv", number = 10, repeats = 3)
svm_Linear <- train(crops ~., data = training1, method = "svmLinear",
                    trControl=trctrl,
                    preProcess = c("center", "scale"),
                    tuneLength = 10)
svm_Linear
test_pred <- predict(svm_Linear, newdata = testing1)
test_pred
confusionMatrix(table(test_pred, testing1$crops))

##we will try to build a model using Non-Linear Kernel like Radial Basis Function.
##For using RBF kernel, we just need to change our train() method’s “method” parameter to “svmRadial”.
set.seed(3233)
svm_Radial <- train(crops ~., data = training1, method = "svmRadial",
                    trControl=trctrl,
                    preProcess = c("center", "scale"),
                    tuneLength = 10)
svm_Radial
plot(svm_Radial)
test_pred_Radial <- predict(svm_Radial, newdata = testing)


#random forest
# Set a random seed
set.seed(51)
# Training using a random forest algorithm
rfmodel <- train(crops ~ Nitrogen + Phosphorus + Potassium + rainfall + humidity + ph+ temperature,
                 data = training1,method = 'rf',
                 trControl = trainControl(method = 'cv', number = 5) )
rfmodel
testing1$crops <- predict(model, newdata = testing1)
testing1$crops
plot(rfmodel)

#knn
cropsugg=read.csv("C:/Users/Eathish/Desktop/AI ASSISTED FARMING AND CROP YIELD PREDICTION/DATA FILE/TAMILNADU_CROP_PRODUCTION.csv")#importing dataset
df <- data.frame( label = c("apple","banana", "blackgram", "chickpea", "coconut","coffee","cotton","grapes","jute","kidneybeans","lentil","maize","mango","mothbeans","mungbean","muskmelon","orange","papaya","pigeonpeas","pomegranate","rice","watermelon")) 
cropsugg$crops <- as.numeric( factor(cropsugg$crops) ) -1
#Normalization
normalize <- function(x) {
  return ((x - min(x)) / (max(x) - min(x))) }
cropsugg_norm <- as.data.frame(lapply(cropsugg[,1:7], normalize))
head(cropsugg_norm)
set.seed(123)
cropsugg1 <- sample(1:nrow(cropsugg_norm),size=nrow(cropsugg_norm)*0.8,replace = FALSE) #random selection of 80% data.

train<- cropsugg[cropsugg1,] # 80% training data
test <- cropsugg[-cropsugg1,] # remaining 20% test data
trainlab <- cropsugg[cropsugg1,8]
testlab <-cropsugg[-cropsugg1,8]
library(class)
NROW(train) 
##square root of no of observations is our k value we have got 41.95 we will take 39,40,41,42
knn.39 <- knn(train=train, test=test, cl=trainlab, k=39)
knn.40 <- knn(train=train, test=test, cl=trainlab, k=40)
knn.41 <- knn(train=train, test=test, cl=trainlab, k=41)
knn.42 <- knn(train=train, test=test, cl=trainlab, k=42)
#Calculate the proportion of correct classification for k = 39, 40,41,42
ACC.39 <- 100 * sum(testlab == knn.39)/NROW(testlab)
ACC.40 <- 100 * sum(testlab == knn.40)/NROW(testlab)
ACC.41 <- 100 * sum(testlab == knn.41)/NROW(testlab)
ACC.42 <- 100 * sum(testlab == knn.41)/NROW(testlab)
ACC.39
ACC.40
ACC.41
ACC.42
##the accuracy for k=39 is 97.04545 so we will take k=39 for this dataset
# Check prediction against actual value in tabular form for k=39
table(knn.39 ,testlab)

# Check prediction against actual value in tabular form for k=40
table(knn.40 ,testlab)
confusionMatrix(table(knn.39 ,testlab))
confusionMatrix(table(knn.40 ,testlab))
i=1
k.optm=1
for (i in 1:41){
  knn.mod <- knn(train=train, test=test, cl=trainlab, k=i)
  k.optm[i] <- 100 * sum(testlab == knn.mod)/NROW(testlab)
  k=i
  cat(k,'=',k.optm[i],'
')
}
#Accuracy plot
plot(k.optm, type="b", xlab="K- Value",ylab="Accuracy level")
