cropprod=read.csv("C:/Users/Eathish/Desktop/AI ASSISTED FARMING AND CROP YIELD PREDICTION/DATA FILE/areavsprod.csv")
head(cropprod)##list some rows of dataset
View(cropprod)##to view the dataSet in tabular form
table(cropprod$crops)##to check how many categorical variables are arranged
dim(cropprod)##to check the no of rows and columns
which(is.na(cropprod))#this check for the nan values

##this dataset doesnt have nan values

##visualization
y<-table(cropprod$area,cropprod$production_tonn)#table between distribution of Area of cultivation vs Production of crops in tonn
barplot(y,col = "blue",xlab="Area of cultivation",ylab = "Production of crops in tonn",main="frequencies of area VS production")#barplot of frequencies of area and crops
pairs(~area+production_tonn+productivity,data=cropprod)
summary(cropprod)

##using ggplot lets visualize the variables in dataset
library(dplyr)
library(ggplot2)
##Area vs production_tonn
cropprod %>% ggplot(aes(area, production_tonn)) +
  geom_point(color= "blue", alpha = 0.3) +
  ggtitle("Area vs production_tonn") +
  xlab("Area") +
  ylab("production_tonn") +
  theme(plot.title = element_text(color="darkred",
                                  size=18,hjust = 0.5),
        axis.text.y = element_text(size=12),
        axis.text.x = element_text(size=12,hjust=.5),
        axis.title.x = element_text(size=14),
        axis.title.y = element_text(size=14))
##Area vs productivity
cropprod %>% ggplot(aes(area, productivity)) +
  geom_point(color= "blue", alpha = 0.3) +
  ggtitle("Area vs productivity") +
  xlab("Area") +
  ylab("production_tonn") +
  theme(plot.title = element_text(color="darkgreen",
                                  size=18,hjust = 0.5),
        axis.text.y = element_text(size=12),
        axis.text.x = element_text(size=12,hjust=.5),
        axis.title.x = element_text(size=14),
        axis.title.y = element_text(size=14))
##production_tonn vs productivity
cropprod %>% ggplot(aes(production_tonn, productivity)) +
  geom_point(color= "red", alpha = 0.3) +
  ggtitle("production_tonn vs productivity") +
  xlab("production_tonn") +
  ylab("productivity") +
  theme(plot.title = element_text(color="darkgreen",
                                  size=18,hjust = 0.5),axis.text.y = element_text(size=12),
        axis.text.x = element_text(size=12,hjust=.5),axis.title.x = element_text(size=14),
        axis.title.y = element_text(size=14))



set.seed(100)  # For reproducibility
library(caret)
library(dplyr)
# Create index for testing and training data
inTrain <- createDataPartition(y = cropprod$productivity, 
                               p = 0.8, list = FALSE)
# subset crop production dataset to training
training <- cropprod[inTrain,]
# subset the rest to test
testing <- cropprod[-inTrain,]
# Size ratio of training and test dataset
message("As shown below, the training set is about 80%  and the test set is about 20% of the original data")
rbind("Training set" = nrow(training)/nrow(cropprod),
      "Testing set" = nrow(testing)/nrow(cropprod)) %>% 
  round(2)*100
my_lm <- train(training[,1:3], training[,4],
               method = "lm",
               preProc = c("center", "scale")
)
message("Mulitiple Linear Regression: Model performance on \n the training set")
my_lm$results[c("RMSE","Rsquared")] %>%
  round(2)
summary(my_lm)


#svm
trctrl <- trainControl(method = "repeatedcv", number = 10, repeats = 3)
svm_Linear <- train(productivity ~., data = training, method = "svmLinear",
                    trControl=trctrl,
                    preProcess = c("center", "scale"),
                    tuneLength = 10)
svm_Linear
test_pred <- predict(svm_Linear, newdata = testing)
test_pred

##we will try to build a model using Non-Linear Kernel like Radial Basis Function.
##For using RBF kernel, we just need to change our train() method’s “method” parameter to “svmRadial”.
set.seed(3233)
svm_Radial <- train(productivity ~., data = training, method = "svmRadial",
                      trControl=trctrl,
                      preProcess = c("center", "scale"),
                      tuneLength = 10)
svm_Radial
plot(svm_Radial)

#random forest
# Set a random seed
set.seed(51)
# Training using random forest  algorithm
rfmodel <- train(productivity ~.,data = training,method = 'rf',trControl = trainControl
                 (method = 'cv', number = 5) )
rfmodel
testing$productivity <- predict(rfmodel, newdata = testing)
testing$productivity
plot(rfmodel)

#knn
trctrl <- trainControl(method = "repeatedcv", number = 10, repeats = 3)
set.seed(3333)
knn_fit <- train(productivity ~., data = training, method = "knn",
                 trControl=trctrl,
                 preProcess = c("center", "scale"),
                 tuneLength = 10)
knn_fit
plot(knn_fit)

