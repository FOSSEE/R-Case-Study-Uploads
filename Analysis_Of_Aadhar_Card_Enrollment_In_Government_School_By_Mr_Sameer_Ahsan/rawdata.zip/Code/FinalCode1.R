# Importing libraries
# shiny package in R is used to build interactive web apps
library(shiny)

# Dplyr package in R is used for data manipulation
library(dplyr)

# ggplot package in R is used for data visualization
library(ggplot2)

# maps package in R contains lot of outlines of continents, states and counties 
library(maps)

# mapproj package in R converts latitude and longitude into projected coordinates
library(mapproj)

# sp package in R deals with the spatial data
library(sp)

# RcolorBrewer package in r helps to manage colors with R
library(RColorBrewer)

# ggmap can be used to use google map services and also help to plot them using ggplot
library(ggmap)

# rgdal is used for Geospatial' Data Abstraction
library(rgdal)

# scales helps to build scaling infrastructure used by ggplot2
library(scales)

# helps to handle spatial objects
library(maptools)

# It provides useful grid extensions
library(gridExtra)

# It helps in manipulation and querying of spatial geometries
library(rgeos)

# It helps to encode spatial vector data
library(sf)

# It helps to scrap data from web pages
library(rvest)

# viridis package in R helps to give colors to map for better readability for users
library(viridis)

# ggrepel helps to repel overlapping text labels
library(ggrepel)

# used for changes background theme, title theme and others
library(ggthemes)

# helps to create and integrate maps
library(cartography)

# It helps in grammar and data structures
library(tidyverse)

# It helps to include foreign data formats
library(haven)

# readxl package in R is used to get the data from excel in R
library(readr)

# It helps switch scientific notations to larger numbers
options(scipen=999)

# To read excel file
library(readxl)
# reading data from Data.xlsx  file for varanasi district schools(file given in zip file)
Data <- read_excel("Data.xlsx")
View(Data)


# Datad variable is taken and by using select function we can select the columns from Data excel file
Datad <- select(Data,
                School_Name,
                Enrollment_Status,
                Aadhaar_card_Status_Available,
                Aadhar_card_not_available)

View(Datad)


# reading data from Sultanpur.xlsx  file for sultanpur district schools(file given in zip file)
Sultanpur <- read_excel("Sultanpur.xlsx")
View(Data)


# DataS variable is taken and by using select function we can select the columns from sultanpur excel file
DataS <- select(Sultanpur,
                School_Name,
                Enrollment_Status,
                Aadhaar_card_Status_Available,
                Aadhar_card_not_available)
View(DataS)







# typeof function in R is used to identify the types of data used
typeof(Data)

# summary function in R is used to summaries the data
summary(Data)

# class function is used to return the class attribute of object
class(Data)

# str function displays the internal structure of data
str(Data)




# typeof function in R is used to identify the types of data used
typeof(Sultanpur)

# summary function in R is used to summaries the data
summary(Sultanpur)

# class function is used to return the class attribute of object
class(Sultanpur)

# str function displays the internal structure of data
str(Sultanpur)


# First set the working directory to uttar_pradesh_administrative (1) to use the shapefile for Map.
#(This file is given in the zip folder)


# Storing the data in a variable by st_read()
sa <- st_read("uttar_pradesh_administrative.shp")

# setting the column null
sa$ADMIN_LEVE <- NULL

# reading the csv file with the help of read_csv
jiji <- read_csv("jiji.csv")

# merging the data file with shapefile to get the coordinates
k <- merge(sa,jiji, by ="NAME",all=TRUE)
View(k)

# It helps to remove NA value
e <- na.omit(k)

# helps to keep unique rows from the data frame
d <- distinct(e,NAME,Verified,geometry)

# remove duplicate data from data frame
h <- d[!duplicated(d$NAME),]
View(h)

# Creating the map to show the distribution
points<-cbind(h, st_coordinates(st_centroid(h$geometry)))
ggplot(data = points) +
  geom_sf(aes(fill=Verified), color="black", size=0.2) +
  scale_fill_viridis_c(option = "viridis", trans = "sqrt")+
  geom_text(data= points,aes(x=X, y=Y, label=paste(NAME)),
            color = "darkblue", size=2.5, fontface = "italic", angle=0, vjust=-1, check_overlap = FALSE) +
  geom_text(data= points,aes(x=X, y=Y, label=paste(Verified)),
            color = "white", size=2.0, fontface = "bold", angle=0, vjust=+1, check_overlap = FALSE) +
  ggtitle("Aadhaar Card Available")+xlab("Longitude")+ylab("Latitude")+
  
  theme(
    panel.background = element_rect(fill='lightblue', size=0.5,
                                    linetype=0, colour='lightblue'),
    plot.title = element_text(color="red", size=16, hjust=0.5, face="bold.italic"),
    axis.title.x = element_text(color="blue", size=10, face="bold"),
    axis.title.y = element_text(color="red", size=10, face="bold")
  )






# UI for app that draws a histogram
ui <- fluidPage(
  
  # App title
  titlePanel("Analyzing strength!"),
  
  # Sidebar layout with input and output definitions
  sidebarLayout(
    
    # Sidebar panel for inputs
    sidebarPanel(
      
      # Input: Slider for the number of Schools
      sliderInput(inputId = "bins",
                  label = "Number of districts:",
                  min = 1,
                  max = 78,
                  value = 100)
      
    ),
    
    # Main panel for displaying outputs
    mainPanel(
      
      # Output: Histogram 
      plotOutput(outputId = "distPlot")
      
    )
  )
)

# Define server logic required to draw a histogram ----
server <- function(input, output) {
  
  output$distPlot <- renderPlot({
    
    x    <- h$Verified
    bins <- seq(min(x), max(x), length.out = input$bins + 1)
    
    hist(x, breaks = bins, col = "#75AADB", border = "white",
         xlab = "Aadhaar card verified  (in thousands)",
         main = "Histogram showing aadhaar status ")
    
  })
  
}

# Create Shiny app ----
shinyApp(ui = ui, server = server)





# plot function is used in R to draw points
plot(Sultanpur$Aadhaar_card_Status_Available, Sultanpur$Enrollment_Status,
     pch = 19, col = "black")

# abline function is used to add one or more straight lines to a graph and lm function is used to fit linear models.
abline(lm(Sultanpur$Aadhaar_card_Status_Available ~ Sultanpur$Enrollment_Status),
       col = "red", lwd = 3)

# text function is used to draw text elements and paste function is used to concatenate vectors by converting them into character.
text(paste("Correlation:", round(cor(Sultanpur$Aadhaar_card_Status_Available, Sultanpur$Aadhar_card_not_available), 2)), x = 100, y = 300)




# plot function is used in R to draw points
plot(Data$Aadhaar_card_Status_Available, Data$Enrollment_Status,
     pch = 19, col = "black")

# abline function is used to add one or more straight lines to a graph and lm function is used to fit linear models.
abline(lm(Data$Aadhaar_card_Status_Available ~ Data$Enrollment_Status),
       col = "red", lwd = 3)

# text function is used to draw text elements and paste function is used to concatenate vectors by converting them into character.
text(paste("Correlation:", round(cor(Sultanpur$Aadhaar_card_Status_Available, Sultanpur$Aadhar_card_not_available), 2)), x = 100, y = 300)








# geom_point function in R is used to plot scatter plot
ggplot(data = Data,
       mapping = aes(x= School_Name,cex.axis = 1.5,
                     y= Aadhaar_card_Status_Available,
                     col= "red",)) +
  geom_point() + 
  theme(axis.text.x = element_text(angle = 90,vjust = 0.3))




# ggplot plots the complex plots and aes function in R is used to specify the desired aesthetics
# geom_point function in R is used to plot scatter plot
ggplot(data = Sultanpur,
       mapping = aes(x= School_Name,cex.axis = 1.5,
                     y= Aadhaar_card_Status_Available,
                     col= "red",)) +
  geom_point() + 
  theme(axis.text.x = element_text(angle = 90,vjust = 0.3))



# set the plotting area into a 1*2 array
par(mfrow = c(1, 2))    

# Draw the two line chart using above datasets
plot(Sultanpur$Aadhaar_card_Status_Available, type="o", col="green")
plot(Datad$Aadhaar_card_Status_Available, type="o", col="red")




plot(Sultanpur$Aadhaar_card_Status_Available,type = "o",col = "green", xlab = "Schools", ylab = "Aadhar Card Status", 
     main = "Comparison of Aadhaar Availability ")

# lines function is used to add different types, colors and width to the existing plot
lines(Datad$Aadhaar_card_Status_Available, type = "o", col = "red")

# legend function is used to describe the each part of the plot
legend("topright",
       c("Aadhar Available of Sultanpur","Aadhar Available of Varanasi"),cex = 0.2,
       fill = c("green","red") 
)











